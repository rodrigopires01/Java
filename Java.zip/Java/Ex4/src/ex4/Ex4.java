package ex4;

import java.util.Scanner;

public class Ex4 {

    public static void main(String[] args) {

        String continuar, fruta;
        int x = 0, tentativas = 0, novas = 0, total = 0;
        String[] frutas = new String[1];

        do {
            Scanner scan = new Scanner(System.in);
            System.out.print("Insere uma fruta: ");
            fruta = scan.nextLine();
            total++;

            if (fruta.contains(" ")) {
                System.out.println("Só podes inserir frutos com uma palavra!");
                tentativas++;
            } else if (check(frutas, fruta)) {
                System.out.println("Essa fruta ja foi inserida!");
                tentativas++;
            } else {
                System.out.println("Não conhecia essa fruta!");
                frutas[x++] = fruta;
                novas++;
                if (x == frutas.length) {
                    String[] frutas2 = new String[x * 2];
                    System.arraycopy(frutas, 0, frutas2, 0, frutas.length);
                    frutas = frutas2;
                }
            }

            System.out.print("Continuar? (s/n)");
            continuar = scan.next();
        } while (continuar.equals("s"));

        System.out.println("----------------------");
        System.out.print("Lista de Frutas: ");
        for (int i = 0; i < novas; i++) {
            System.out.print(frutas[i] + " ");
        }
        System.out.println("\nTotal: " + total);
        System.out.println("Tentativas: " + tentativas);
        System.out.println("Novas: " + novas);
    }

    private static boolean check(String[] lista, String palavra) {
        for (int i = 0; i < lista.length; i++) {
            if (palavra.equals(lista[i])) {
                return true;
            }
        }
        return false;
    }
}
