package Ex2;

import java.util.Scanner;

public class Ex2 {

    public static void main(String[] args) {
        

        String ilhas[] = {"Terceira", "São Miguel", "Sta Maria", "S. Jorge", "Pico"};
        int vendas[] = {0, 0, 0, 0, 0};

        for (int i = 0; i < vendas.length; i++) {
            Scanner scan = new Scanner(System.in);
            System.out.print("Insere vendas para " + ilhas[i] + ": ");
            vendas[i] = scan.nextInt();
        }

        int total = 0, media, maior = vendas[0], menor = vendas[0];
        String maiorI = ilhas[0], menorI = ilhas[0];

        for (int i = 0; i < vendas.length; i++) {
            System.out.println(ilhas[i] + ": " + vendas[i]);
            total += vendas[i];
            if (i > 0) {
                if (vendas[i] > maior) {
                    maior = vendas[i];
                    maiorI = ilhas[i];
                }
                if (vendas[i] < menor) {
                    menor = vendas[i];
                    menorI = ilhas[i];
                }
            }

        }

        media = total / vendas.length;

        System.out.printf("Total Vendas: %d | Média: %d | Maior(%s): %d | Menor(%s): %d\n", total, media, maiorI, maior, menorI, menor);

    }
}
