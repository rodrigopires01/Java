import java.util.Scanner;

public class ExConsole2 {

    public static void main(String[] args) {

        int nota = 0;
        String continuar = "";

        do {
            Scanner scan = new Scanner(System.in);
            do {
                System.out.print("Insira a nota da escala de 0 a 100: ");
                nota = scan.nextInt();
            } while (nota < 0 || nota > 100);

            System.out.println("A nota " + nota + " corresponde a um " + calcularNota(nota));

            System.out.print("Continuar? (s/n)");
            continuar = scan.next();
        } while (continuar.equals("s"));

    }

    private static String calcularNota(int nota) {
        if (nota >= 0 && nota <= 10) {
            return "F";
        } else if (nota >= 11 && nota <= 30) {
            return "E";
        } else if (nota >= 31 && nota <= 50) {
            return "D";
        } else if (nota >= 51 && nota <= 70) {
            return "C";
        } else if (nota >= 71 && nota <= 90) {
            return "B";
        } else if (nota >= 91 && nota <= 100) {
            return "A";
        } else {
            return "Erro!";
        }
    }
}
