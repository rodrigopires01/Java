
import java.util.Scanner;

public class ExConsole3 {

    public static void main(String[] args) {

        int ilha = 0;
        String[] ilhas = {"São Miguel", "Santa Maria", "Terceira", "Pico", "Faial", "São Jorge", "Graciosa", "Flores", "Corvo"};
        String continuar = "";

        do {
            Scanner scan = new Scanner(System.in);

            System.out.print("Escreva o número da ilha: ");
            ilha = scan.nextInt();

            validarIlha(ilhas, ilha);

            System.out.print("Continuar? (s/n)");
            continuar = scan.next();
        } while (continuar.equals("s"));
    }

    private static void validarIlha(String[] ilhas, int ilha) {
        switch (ilha) {
            case 1:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 2:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 3:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 4:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 5:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 6:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 7:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 8:
                System.out.println(ilhas[ilha - 1]);
                break;
            case 9:
                System.out.println(ilhas[ilha - 1]);
                break;
            default:
                System.out.println("Insira um número entre 1 e 9 !");
        }
    }
}
