package ex6;

public class Ex6 {

    public static void main(String[] args) {
        
        int[] lista = {1, 2, 3, 4, 5, 6};
        
        for (int a = 0; a < lista[lista.length-1]; a++){
            System.out.println(lista[a]);
        }
    }
}
