package testesrapidos;

import java.util.Random;

public class TestesRapidos {
    
    public static void main(String[] args) {
        
        Random r = new Random();
        
        int[] valores = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        
        
        
        System.out.println(valores);
    }
}