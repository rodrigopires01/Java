
public class NewApplication extends javax.swing.JFrame {

    public NewApplication() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        nome = new javax.swing.JLabel();
        datanascimento = new javax.swing.JLabel();
        genero = new javax.swing.JLabel();
        macho = new javax.swing.JRadioButton();
        femea = new javax.swing.JRadioButton();
        inputNome = new javax.swing.JTextField();
        inputNascimento = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        output = new javax.swing.JTextArea();
        process = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        localidade = new javax.swing.JLabel();
        inputLocalidade = new javax.swing.JComboBox<>();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        openMenuItem = new javax.swing.JMenuItem();
        saveMenuItem = new javax.swing.JMenuItem();
        saveAsMenuItem = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        cutMenuItem = new javax.swing.JMenuItem();
        copyMenuItem = new javax.swing.JMenuItem();
        pasteMenuItem = new javax.swing.JMenuItem();
        deleteMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        contentsMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        nome.setText("Nome:");

        datanascimento.setText("Data Nascimento: ");

        genero.setText("Gênero:");

        buttonGroup1.add(macho);
        macho.setSelected(true);
        macho.setText("Masculino");

        buttonGroup1.add(femea);
        femea.setText("Feminino");

        inputNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputNomeActionPerformed(evt);
            }
        });

        jLabel1.setText("Output:");

        output.setEditable(false);
        output.setColumns(20);
        output.setRows(5);
        jScrollPane1.setViewportView(output);

        process.setText("Processar");
        process.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                processActionPerformed(evt);
            }
        });

        clear.setText("Limpar");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        localidade.setText("Localidade:");

        inputLocalidade.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        inputLocalidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inputLocalidadeActionPerformed(evt);
            }
        });

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        openMenuItem.setMnemonic('o');
        openMenuItem.setText("Open");
        fileMenu.add(openMenuItem);

        saveMenuItem.setMnemonic('s');
        saveMenuItem.setText("Save");
        fileMenu.add(saveMenuItem);

        saveAsMenuItem.setMnemonic('a');
        saveAsMenuItem.setText("Save As ...");
        saveAsMenuItem.setDisplayedMnemonicIndex(5);
        fileMenu.add(saveAsMenuItem);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        editMenu.setMnemonic('e');
        editMenu.setText("Edit");

        cutMenuItem.setMnemonic('t');
        cutMenuItem.setText("Cut");
        editMenu.add(cutMenuItem);

        copyMenuItem.setMnemonic('y');
        copyMenuItem.setText("Copy");
        editMenu.add(copyMenuItem);

        pasteMenuItem.setMnemonic('p');
        pasteMenuItem.setText("Paste");
        editMenu.add(pasteMenuItem);

        deleteMenuItem.setMnemonic('d');
        deleteMenuItem.setText("Delete");
        editMenu.add(deleteMenuItem);

        menuBar.add(editMenu);

        helpMenu.setMnemonic('h');
        helpMenu.setText("Help");

        contentsMenuItem.setMnemonic('c');
        contentsMenuItem.setText("Contents");
        helpMenu.add(contentsMenuItem);

        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("About");
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(nome)
                        .addGap(96, 96, 96)
                        .addComponent(inputNome))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(genero)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(process)
                                .addGap(39, 39, 39)
                                .addComponent(clear, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(datanascimento)
                                    .addComponent(localidade))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(macho)
                                        .addGap(77, 77, 77)
                                        .addComponent(femea))
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(inputLocalidade, javax.swing.GroupLayout.Alignment.LEADING, 0, 149, Short.MAX_VALUE)
                                        .addComponent(inputNascimento, javax.swing.GroupLayout.Alignment.LEADING)))))
                        .addGap(0, 90, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nome)
                    .addComponent(inputNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(datanascimento)
                    .addComponent(inputNascimento, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(genero)
                    .addComponent(macho)
                    .addComponent(femea))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(localidade)
                    .addComponent(inputLocalidade, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 147, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(process)
                    .addComponent(clear))
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void inputNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inputNomeActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        inputNome.setText("");
        inputNascimento.setText("");
        macho.setSelected(true);
        output.setText("");
    }//GEN-LAST:event_clearActionPerformed

    private void processActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_processActionPerformed
        String nome = inputNome.getText();

        int espaços = 0;
        int naoEspaços = 0;

        for (int x = 0; x < nome.length(); x++) {
            if (nome.charAt(x) == ' ') {
                espaços += 1;
            } else {
                naoEspaços++;
            }

            if (espaços >= 2 && naoEspaços >= 4) {
                output.setText("o nome é válido!" + "\n");
            } else {
                output.setText("o nome não é válido!" + "\n");
            }
        }

        String data = inputNascimento.getText();
        boolean dmavalido = true;

        if (data.length() != 10) {
            output.setText("A data e invalida! \n");
        } else {
            if (data.charAt(2) != '-' || data.charAt(5) != '-') {
                output.setText("A data e invalida! \n");
            } else {
                int dia = 0, mes = 0, ano = 0;

                try {
                    dia = Integer.parseInt(data.substring(0, 2));
                } catch (Exception e) {
                    dmavalido = false;
                    output.setText("O dia inserido é inválido \n!");
                }
                try {
                    mes = Integer.parseInt(data.substring(3, 5));
                } catch (Exception e) {
                    dmavalido = false;
                    output.setText("O mês inserido é inválido \n!");
                }
                try {
                    ano = Integer.parseInt(data.substring(6, 10));
                } catch (Exception e) {
                    dmavalido = false;
                    output.setText("O ano inserido é inválido!\n");
                }

                if (dmavalido) {
                    boolean datavalida = true;
                    int[] dias = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
                    if (mes == 2) {
                        if (ano % 4 == 0) {
                            if (dia < 1 || dia > 29) {
                                datavalida = false;
                                output.setText("O dia inserido é invalido! \n");
                            }
                        } else {
                            if (dia < 1 || dia > 28) {
                                datavalida = false;
                                output.setText("O dia inserido é invalido! \n");
                            }
                        }
                    } else {
                        if (mes < 1 || mes > 12){
                            datavalida = false;
                            output.setText("O mês inserido é invalido! \n");
                        }
                        if (dia < 1 || dia > dias[mes - 1]) {
                            datavalida = false;
                            output.setText("O dia inserido é invalido! \n");
                        }
                    }
                    if (dia < 1 || dia > 31) {
                        datavalida = false;
                        output.setText("O dia inserido é inválido! \n");
                    }
                    if (mes < 1 || mes > 12) {
                        datavalida = false;
                        output.setText("O mês inserido é inválido! \n");
                    }
                    if (ano <= 1900) {
                        datavalida = false;
                        output.setText("O ano inserido é inválido! \n ");
                    }
                    
                    String[] mesextenso = {"Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"};
                    
                    if (datavalida) {
                        output.setText(inputNome.getText()+" nasceu a "+dia+ " de "+mesextenso[mes-1]+" de "+ano);
                    }
                }
            }
        }
        /*
        output.append(data.substring(0, 2) + "\n");
        output.append(data.charAt(2) + "\n");
        output.append(data.substring(3, 5) + "\n");
        output.append(data.charAt(5) + "\n");
        output.append(data.substring(6, 10) + "\n");

        output.setText(output.getText() + inputNome.getText() + "\n" + inputNascimento.getText() + "\n");
         */
    }//GEN-LAST:event_processActionPerformed

    private void inputLocalidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputLocalidadeActionPerformed

    }//GEN-LAST:event_inputLocalidadeActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewApplication.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewApplication().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton clear;
    private javax.swing.JMenuItem contentsMenuItem;
    private javax.swing.JMenuItem copyMenuItem;
    private javax.swing.JMenuItem cutMenuItem;
    private javax.swing.JLabel datanascimento;
    private javax.swing.JMenuItem deleteMenuItem;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JRadioButton femea;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JLabel genero;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JComboBox<String> inputLocalidade;
    private javax.swing.JTextField inputNascimento;
    private javax.swing.JTextField inputNome;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel localidade;
    private javax.swing.JRadioButton macho;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JLabel nome;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JTextArea output;
    private javax.swing.JMenuItem pasteMenuItem;
    private javax.swing.JButton process;
    private javax.swing.JMenuItem saveAsMenuItem;
    private javax.swing.JMenuItem saveMenuItem;
    // End of variables declaration//GEN-END:variables

}
