package ex5;

public class Ex5 {
    
    private static int guardas[] = {1, 500000};
    
    private static void escapar(int[] lista) {
        
        int x = 0;
        int total = 0;
        int loop = 0;
        
        for (int i = 0; i < lista.length; i++){
            if (lista[i] > loop){

                loop = lista[i];
            }
        }
        
        do {
            for (int i = 0; i < loop; i++){
                if (lista[x] > lista[x+1]){
                    total = lista[x] + lista[x+1];
                    lista[x+1] = lista[x+1] * 2;
                    lista[x] = total - lista[x+1];
                } else {
                    total = lista[x] + lista[x+1];
                    lista[x] = lista[x] * 2;
                    lista[x+1] = total - lista[x];
                }
            }
            
            if (lista[x] == total || lista[x+1] == total){
                System.out.println("Os guardas "+(x+1)+" e "+(x+2)+" estão atentos!");
            } else {
                System.out.println("Os guardas "+(x+1)+" e "+(x+2)+" estão a jogar, dá para fugir!");
            }
            x = x + 2;
        } while (x < lista.length - 1);
    }
    
    public static void main(String[] args) {
        
        if (guardas.length % 2 != 0){
            System.out.println("A lista não é par.");
            System.exit(0);
        }
        
        escapar(guardas);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}