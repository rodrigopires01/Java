package Ex1;
import java.sql.*;

public class Ex1 {

    private static int div3 = 0;
    private static int div7 = 0;
    private static int pares = 0;
    private static int impares = 0;
    private static int soma = 0;

    public static void main(String[] args) {
        for (int x = 50; x <= 100; x++) {

            calcular(x);

        }

        System.out.printf("Soma: %d Divisiveis por 3: %d Divisiveis por 7: %d Pares: %d Impares: %d\n", soma, div3, div7, pares, impares);
        limpar();

        int x = 50;
        while (x <= 100) {
            calcular(x);
            x++;
        }

        System.out.printf("Soma: %d Divisiveis por 3: %d Divisiveis por 7: %d Pares: %d Impares: %d\n", soma, div3, div7, pares, impares);
        limpar();

        x = 50;

        do {
            calcular(x);
            x++;
        } while (x <= 100);

        System.out.printf("Soma: %d Divisiveis por 3: %d Divisiveis por 7: %d Pares: %d Impares: %d\n", soma, div3, div7, pares, impares);

    }

    private static void limpar() {
        div3 = 0;
        div7 = 0;
        soma = 0;
        pares = 0;
        impares = 0;
    }

    private static void calcular(int x) {
        soma += x;

        if (x % 3 == 0) {
            div3 += 1;
        }
        if (x % 7 == 0) {
            div7 += 1;
        }
        if (x % 2 == 0) {
            pares += 1;
        } else {
            impares += 1;
        }
    }

}
