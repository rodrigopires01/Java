package Ex3;

import java.util.Scanner;

public class Ex3 {

    public static void main(String[] args) {

        String continuar;
        int inserido = 0,x = 0, par = 0, impar = 0, total = 0;
        int[] inseridos = new int[10];

        do {
            Scanner scan = new Scanner(System.in);
            do {
                System.out.print("Insere números entre 1-99: ");
                inserido = scan.nextInt();
                if (inserido <= 0 || inserido >= 100) {
                    System.out.println("O número {" + inserido + "} não está entre 1-99!");
                    break;
                }
                if (check(inseridos, inserido)) {
                    if (x == inseridos.length) {
                        int[] inseridos2 = new int[x * 2];
                        System.arraycopy(inseridos, 0, inseridos2, 0, inseridos.length);
                        inseridos = inseridos2;
                    }
                    inseridos[x++] = inserido;
                }
                if (inserido % 2 == 0) {
                    System.out.println("O número {" + inserido + "} é par!");
                    par++;
                } else {
                    System.out.println("O número {" + inserido + "} é impar!");
                    impar++;
                }
                total++;
            } while (inserido < 0 || inserido > 100);

            System.out.print("Continuar? (s/n)");
            continuar = scan.next();
        } while (continuar.equals("s"));

        System.out.println("Total de números inseridos: " + total);
        System.out.println("Total de números par inseridos: " + par);
        System.out.println("Total de números impar inseridos: " + impar);
    }

    private static boolean check(int[] lista, int valor) {
        for (int element : lista) {
            if (element == valor) {
                System.out.println("O número {" + valor + "} já foi inserido antes!");
                return true;
            }
        }
        return false;
    }
}
